/// <mls shortName="designSystem" project="102028" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
