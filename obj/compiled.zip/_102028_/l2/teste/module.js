/// <mls shortName="module" project="102028" enhancement="_blank" folder="teste" />
export const moduleConfig = {
    theme: "default",
    initialPage: "pageTeste",
    menu: []
};
