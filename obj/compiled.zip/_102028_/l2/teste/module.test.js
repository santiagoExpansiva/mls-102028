/// <mls shortName="module" project="102028" enhancement="_blank" folder="teste" />
export const integrations = [];
export const tests = [];
