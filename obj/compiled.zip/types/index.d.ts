declare module "_102028_/l2/ateste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102028_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
