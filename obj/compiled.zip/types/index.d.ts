declare module "_102028_/l2/ateste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare function calculateAge(birthYear: number): number;
declare module "_102028_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102028_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: {
            name: string;
            path: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102028_/l2/teste/module.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102028_/l2/teste/module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: any[];
    };
}
