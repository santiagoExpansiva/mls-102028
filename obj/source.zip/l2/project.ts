/// <mls shortName="project" project="102028" enhancement="_100554_enhancementLit" groupName="other" />

export const projectConfig = {
    masterFrontEnd: {
        build: '',
        start: '',
        liveView: '',
    },
    masterBackEnd: {
        build: '',
        start: '',
        serverView: ''
    },
    modules: []
}